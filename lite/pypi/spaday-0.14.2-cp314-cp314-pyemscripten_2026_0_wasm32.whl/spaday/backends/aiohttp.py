"""aiohttp backend.

- ``mount(app, page, *, prefix="", …)`` — add spaday's routes to an **existing** ``aiohttp.web.Application``
  (call before the app runs; the router freezes on startup).
- ``serve(page, …) -> aiohttp.web.Application`` — create an app, ``mount`` onto it, and run ``background``
  coroutines for its lifetime.

aiohttp is imported inside the functions so importing spaday never requires it. The transports websocket
is **not** generated here (aiohttp owns its websocket API): add the ``{prefix}/ws`` handler via ``routes``
when ``wire="transports"``. Static pages (``wire=None``) run as-is.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from ..assets import AssetPolicy, asset_bundles
from ..bootstrap import AssetLayout, Lifecycle, Page, TreeMode, bootstrap, bundles_dir, tree_frame, tree_json
from ..packages import PackageRef, package_url_prefix, resolve_component_packages
from ..ui.design import Design, _select_page_design

if TYPE_CHECKING:  # annotations only — aiohttp is imported inside the functions (not a spaday dependency)
    from aiohttp import web


def mount(
    app: web.Application,
    page: Page,
    *,
    prefix: str = "",
    routes: Sequence = (),
    js: str | Path | None = None,
    layout: AssetLayout | None = None,
    title: str = "spaday",
    packages: PackageRef | Sequence[PackageRef] = (),
    wire: str | None = None,
    ws: str = "/ws",
    tree: TreeMode = "json",
    reconnect: bool = False,
    scripts: Sequence[str] = (),
    stylesheets: Sequence[str] = (),
    styles: Sequence[str] = (),
    head: str = "",
    design: Design | str | None = None,
    lifecycle: Lifecycle | None = None,
    assets: AssetPolicy | None = None,
) -> web.Application:
    """Add spaday's routes to an existing aiohttp ``app`` under ``prefix``. ``routes`` is a list of
    ``aiohttp.web`` route defs (``web.get(...)`` — including your ``{prefix}/ws`` handler when wiring
    transports). Returns ``app`` for chaining."""
    from aiohttp import web

    asset_layout = layout or ("source" if js is not None else None)
    component_packages = resolve_component_packages(packages)
    page_design = _select_page_design(design, component_packages, page)
    asset_directory = Path(js) if js is not None else bundles_dir(asset_layout)
    bundles = asset_bundles(asset_directory, component_packages, prefix, assets, source=js is None and asset_directory == bundles_dir("source"))
    body = bootstrap(
        base=prefix,
        packages=component_packages,
        wire=wire,
        ws=ws,
        tree=tree,
        page=page,
        reconnect=reconnect,
        scripts=scripts,
        stylesheets=stylesheets,
        styles=styles,
        head=head,
        title=title,
        layout=asset_layout,
        design=page_design,
        lifecycle=lifecycle,
        _asset_urls={b.prefix: b.url for b in bundles},
    )
    js_dir = str(js) if js is not None else str(bundles_dir(asset_layout))

    async def homepage(_request):
        return web.Response(text=body, content_type="text/html")

    tree_routes = []
    if tree == "frame":

        async def tree_handler(_request):
            return web.Response(body=tree_frame(page, design=page_design), content_type="application/octet-stream")

        tree_routes.append(web.get(f"{prefix}/tree", tree_handler))
    elif tree == "json":

        async def tree_handler(_request):
            return web.Response(text=tree_json(page, page_design), content_type="application/json")

        tree_routes.append(web.get(f"{prefix}/tree.json", tree_handler))

    app.add_routes([web.get(f"{prefix}/", homepage), *tree_routes, *routes])
    if assets is not None:

        def handler(bundle):
            async def respond(request):
                result = await asyncio.to_thread(bundle.response, request.match_info["path"], request.headers, request.method)
                return web.Response(body=result.body, status=result.status, headers=result.headers)

            return respond

        for bundle in bundles:
            app.router.add_get(bundle.prefix + "/{path:.*}", handler(bundle))
    else:
        for package in component_packages:
            app.router.add_static(package_url_prefix(package, prefix), str(package.assets_dir))
        app.router.add_static(f"{prefix}/js", js_dir)
    return app


def serve(page: Page, *, background: Sequence[Awaitable] = (), **opts) -> web.Application:
    """Create an aiohttp app and :func:`mount` ``page`` onto it. ``background`` coroutines run for the
    app's lifetime; all other keyword options are :func:`mount`'s."""
    from aiohttp import web

    app = web.Application()
    mount(app, page, **opts)

    tasks = []  # closed over by the startup/cleanup hooks (avoids an aiohttp app-key)

    async def _start_bg(_app):
        tasks.extend(asyncio.ensure_future(c) for c in background)

    async def _stop_bg(_app):
        for task in tasks:
            task.cancel()

    app.on_startup.append(_start_bg)
    app.on_cleanup.append(_stop_bg)
    return app
