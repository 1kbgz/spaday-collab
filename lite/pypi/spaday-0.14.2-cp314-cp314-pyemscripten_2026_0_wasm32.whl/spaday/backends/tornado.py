"""Tornado backend.

- ``mount(app, page, *, prefix="", …)`` — add spaday's handlers to an **existing** ``tornado.web.Application``.
- ``serve(page, …) -> tornado.web.Application`` — create an app, ``mount`` onto it, and schedule
  ``background`` coroutines on the IOLoop. Run it the usual way::

      app = serve(page, ...); app.listen(8000); tornado.ioloop.IOLoop.current().start()

tornado is imported inside the functions so importing spaday never requires it. The transports ``{prefix}/ws``
endpoint (with ``wire="transports"``) is yours to add via ``routes`` (Tornado has its own ``WebSocketHandler``).
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import Awaitable, Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from ..assets import AssetPolicy, asset_bundles
from ..bootstrap import AssetLayout, Lifecycle, Page, TreeMode, bootstrap, bundles_dir, tree_frame, tree_json
from ..packages import PackageRef, package_url_prefix, resolve_component_packages
from ..ui.design import Design, _select_page_design

if TYPE_CHECKING:  # annotations only — tornado is imported inside the functions (not a spaday dependency)
    from tornado.web import Application


def mount(
    app: Application,
    page: Page,
    *,
    prefix: str = "",
    routes: Sequence = (),
    js: str | Path | None = None,
    layout: AssetLayout | None = None,
    title: str = "spaday",
    packages: PackageRef | Sequence[PackageRef] = (),
    wire: str | None = None,
    ws: str = "/ws",
    tree: TreeMode = "json",
    reconnect: bool = False,
    scripts: Sequence[str] = (),
    stylesheets: Sequence[str] = (),
    styles: Sequence[str] = (),
    head: str = "",
    design: Design | str | None = None,
    lifecycle: Lifecycle | None = None,
    assets: AssetPolicy | None = None,
) -> Application:
    """Add spaday's handlers to an existing Tornado ``app`` under ``prefix``. ``routes`` is a list of
    Tornado handler tuples (``(pattern, Handler[, kwargs])`` — including your ``{prefix}/ws`` handler when
    wiring transports). Returns ``app`` for chaining."""
    from tornado.web import RequestHandler, StaticFileHandler

    asset_layout = layout or ("source" if js is not None else None)
    component_packages = resolve_component_packages(packages)
    page_design = _select_page_design(design, component_packages, page)
    asset_directory = Path(js) if js is not None else bundles_dir(asset_layout)
    bundles = asset_bundles(asset_directory, component_packages, prefix, assets, source=js is None and asset_directory == bundles_dir("source"))
    body = bootstrap(
        base=prefix,
        packages=component_packages,
        wire=wire,
        ws=ws,
        tree=tree,
        page=page,
        reconnect=reconnect,
        scripts=scripts,
        stylesheets=stylesheets,
        styles=styles,
        head=head,
        title=title,
        layout=asset_layout,
        design=page_design,
        lifecycle=lifecycle,
        _asset_urls={b.prefix: b.url for b in bundles},
    )
    js_dir = str(js) if js is not None else str(bundles_dir(asset_layout))
    pre = re.escape(prefix)

    class _Index(RequestHandler):
        def _get(self, *args: str, **kwargs: str) -> None:
            self.set_header("Content-Type", "text/html")
            self.write(body)

        # Match Tornado's mutable callable attribute rather than narrowing it to a method.
        get: Callable[..., Awaitable[None] | None] = _get

    if tree == "frame":

        class _Tree(RequestHandler):
            def _get(self, *args: str, **kwargs: str) -> None:
                self.set_header("Content-Type", "application/octet-stream")
                self.write(tree_frame(page, design=page_design))

            get: Callable[..., Awaitable[None] | None] = _get

        tree_rules = [(rf"{pre}/tree", _Tree)]
    elif tree == "json":

        class _Tree(RequestHandler):
            def _get(self, *args: str, **kwargs: str) -> None:
                self.set_header("Content-Type", "application/json")
                self.write(tree_json(page, page_design))

            get: Callable[..., Awaitable[None] | None] = _get

        tree_rules = [(rf"{pre}/tree\.json", _Tree)]
    else:
        tree_rules = []

    if assets is not None:

        class _Asset(RequestHandler):
            def initialize(self, **kwargs) -> None:
                self.bundle = kwargs["bundle"]

            async def _get(self, path: str) -> None:
                result = await asyncio.to_thread(self.bundle.response, path, self.request.headers, self.request.method)
                self.set_status(result.status)
                for name, value in result.headers.items():
                    self.set_header(name, value)
                self.finish(result.body if result.body else None)

            async def _head(self, path: str) -> None:
                await self._get(path)

            get: Callable[..., Awaitable[None] | None] = _get
            head: Callable[..., Awaitable[None] | None] = _head

        handlers = [(rf"{pre}/", _Index), *tree_rules, *routes, *((rf"{re.escape(b.prefix)}/(.*)", _Asset, {"bundle": b}) for b in bundles)]
    else:
        package_handlers = [
            (
                rf"{re.escape(package_url_prefix(package, prefix))}/(.*)",
                StaticFileHandler,
                {"path": str(package.assets_dir)},
            )
            for package in component_packages
        ]
        handlers = [(rf"{pre}/", _Index), *tree_rules, *routes, *package_handlers, (rf"{pre}/js/(.*)", StaticFileHandler, {"path": js_dir})]
    app.add_handlers(r".*", handlers)
    return app


def serve(page: Page, *, background: Sequence[Awaitable] = (), **opts) -> Application:
    """Create a Tornado application and :func:`mount` ``page`` onto it. ``background`` coroutines are
    scheduled on the IOLoop and run once it starts; all other keyword options are :func:`mount`'s."""
    from tornado.ioloop import IOLoop
    from tornado.web import Application

    app = Application()
    mount(app, page, **opts)
    for coro in background:  # scheduled now, spawned when the IOLoop runs
        IOLoop.current().add_callback(asyncio.ensure_future, coro)
    return app
